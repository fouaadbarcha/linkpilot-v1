<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'LinkPilot' ) ) :

class LinkPilot {

    protected static $instance = null;
    protected $links_table;

    public static function instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        global $wpdb;
        $this->links_table = $wpdb->prefix . 'linkpilot_links';

        add_action( 'admin_menu', array( $this, 'register_admin_menu' ) );
        add_action( 'admin_init', array( $this, 'handle_actions' ) );
        add_action( 'admin_notices', array( $this, 'admin_notices' ) );
    }

    public static function activate() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'linkpilot_links';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL,
            target_url TEXT NOT NULL,
            anchor_text TEXT NOT NULL,
            created_at DATETIME NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            PRIMARY KEY  (id),
            KEY post_id (post_id),
            KEY status (status)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    public function register_admin_menu() {
        add_menu_page(
            __( 'LinkPilot', 'linkpilot' ),
            __( 'LinkPilot', 'linkpilot' ),
            'manage_options',
            'linkpilot-dashboard',
            array( $this, 'render_dashboard_page' ),
            'dashicons-admin-links',
            58
        );

        add_submenu_page(
            'linkpilot-dashboard',
            __( 'Overview', 'linkpilot' ),
            __( 'Overview', 'linkpilot' ),
            'manage_options',
            'linkpilot-dashboard',
            array( $this, 'render_dashboard_page' )
        );

        add_submenu_page(
            'linkpilot-dashboard',
            __( 'Link Activity', 'linkpilot' ),
            __( 'Link Activity', 'linkpilot' ),
            'manage_options',
            'linkpilot-logs',
            array( $this, 'render_logs_page' )
        );

        add_submenu_page(
            'linkpilot-dashboard',
            __( 'Settings', 'linkpilot' ),
            __( 'Settings', 'linkpilot' ),
            'manage_options',
            'linkpilot-settings',
            array( $this, 'render_settings_page' )
        );
    }

    public function handle_actions() {
        if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
            return;
        }

        if ( isset( $_GET['page'] ) && $_GET['page'] === 'linkpilot-dashboard' && isset( $_GET['lp_action'] ) ) {
            $action = sanitize_text_field( $_GET['lp_action'] );

            if ( $action === 'scan_now' ) {
                check_admin_referer( 'linkpilot_scan_now' );
                $result = $this->run_bulk_scan();
                set_transient( 'linkpilot_last_scan_notice', $result, 60 );
                wp_redirect( admin_url( 'admin.php?page=linkpilot-dashboard' ) );
                exit;
            }
        }
    }

    public function admin_notices() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $notice = get_transient( 'linkpilot_last_scan_notice' );
        if ( $notice && is_array( $notice ) ) {
            delete_transient( 'linkpilot_last_scan_notice' );
            ?>
            <div class="notice notice-success is-dismissible">
                <p><strong>LinkPilot:</strong>
                <?php
                    printf(
                        esc_html__( 'Scanned %d posts and inserted %d new links.', 'linkpilot' ),
                        intval( $notice['posts_scanned'] ),
                        intval( $notice['links_inserted'] )
                    );
                ?>
                </p>
            </div>
            <?php
        }
    }

    protected function get_stats() {
        global $wpdb;
        $stats = array(
            'total_links'      => 0,
            'posts_affected'   => 0,
            'last_link_time'   => '',
        );

        $stats['total_links'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->links_table} WHERE status = 'active'" );
        $stats['posts_affected'] = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT post_id) FROM {$this->links_table} WHERE status = 'active'" );
        $stats['last_link_time'] = $wpdb->get_var( "SELECT MAX(created_at) FROM {$this->links_table}" );

        return $stats;
    }

    public function render_dashboard_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'You do not have sufficient permissions to access this page.', 'linkpilot' ) );
        }

        global $wpdb;
        $stats       = $this->get_stats();
        $total_posts = (int) $wpdb->get_var(
            "SELECT COUNT(ID) FROM {$wpdb->posts}
             WHERE post_type = 'post' AND post_status = 'publish'"
        );

        $recent_activity = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$this->links_table}
                 ORDER BY created_at DESC
                 LIMIT %d",
                5
            ),
            ARRAY_A
        );

        $last_run_label = $stats['last_link_time'] ? mysql2date( 'M j, Y H:i', $stats['last_link_time'] ) : 'Not run yet';

        ?>
        <div class="wrap linkpilot-wrap">
            <style>
                .linkpilot-wrap {
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif;
                    max-width: 1100px;
                }
                .lp-header {
                    margin-top: 20px;
                    padding: 20px 24px;
                    border-radius: 16px;
                    background: linear-gradient(135deg, #4F46E5, #EC4899);
                    color: #ffffff;
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    gap: 16px;
                }
                .lp-header-main {
                    max-width: 70%;
                }
                .lp-header-title {
                    font-size: 24px;
                    font-weight: 700;
                    margin: 0 0 6px 0;
                }
                .lp-header-subtitle {
                    margin: 0;
                    font-size: 14px;
                    opacity: 0.9;
                }
                .lp-badge {
                    display: inline-block;
                    padding: 3px 9px;
                    border-radius: 999px;
                    background: rgba(255, 255, 255, 0.2);
                    font-size: 11px;
                    font-weight: 600;
                    text-transform: uppercase;
                    letter-spacing: 0.05em;
                    margin-bottom: 6px;
                }
                .lp-header-actions {
                    display: flex;
                    flex-direction: column;
                    gap: 6px;
                    align-items: flex-end;
                }
                .lp-primary-btn {
                    display: inline-flex;
                    align-items: center;
                    gap: 6px;
                    border-radius: 999px;
                    border: none;
                    padding: 8px 16px;
                    font-size: 13px;
                    font-weight: 600;
                    cursor: pointer;
                    text-decoration: none;
                    background: #ffffff;
                    color: #4F46E5;
                    box-shadow: 0 8px 18px rgba(15, 23, 42, 0.25);
                }
                .lp-secondary-link {
                    font-size: 12px;
                    text-decoration: underline;
                    cursor: pointer;
                    opacity: 0.9;
                }
                .lp-grid {
                    margin-top: 20px;
                    display: grid;
                    grid-template-columns: 2fr 1fr;
                    gap: 16px;
                }
                @media (max-width: 900px) {
                    .lp-grid {
                        grid-template-columns: 1fr;
                    }
                }
                .lp-card {
                    background: #ffffff;
                    border-radius: 14px;
                    padding: 16px 18px;
                    box-shadow: 0 2px 8px rgba(15, 23, 42, 0.05);
                }
                .lp-card-header {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    margin-bottom: 10px;
                }
                .lp-card-title {
                    font-size: 15px;
                    font-weight: 600;
                    margin: 0;
                }
                .lp-card-subtitle {
                    font-size: 12px;
                    color: #6B7280;
                    margin-top: 2px;
                }
                .lp-stats {
                    display: grid;
                    grid-template-columns: repeat(4, minmax(0, 1fr));
                    gap: 12px;
                }
                @media (max-width: 900px) {
                    .lp-stats {
                        grid-template-columns: repeat(2, minmax(0, 1fr));
                    }
                }
                .lp-stat-card {
                    border-radius: 12px;
                    padding: 10px 11px;
                    color: #ffffff;
                    position: relative;
                    overflow: hidden;
                }
                .lp-stat-card::after {
                    content: "";
                    position: absolute;
                    right: -16px;
                    bottom: -16px;
                    width: 60px;
                    height: 60px;
                    border-radius: 999px;
                    background: rgba(255, 255, 255, 0.15);
                }
                .lp-stat-label {
                    font-size: 11px;
                    text-transform: uppercase;
                    letter-spacing: 0.06em;
                    opacity: 0.9;
                    margin-bottom: 4px;
                }
                .lp-stat-value {
                    font-size: 19px;
                    font-weight: 700;
                    line-height: 1.1;
                }
                .lp-stat-meta {
                    font-size: 11px;
                    opacity: 0.9;
                    margin-top: 3px;
                }
                .lp-stat-bg-blue   { background: linear-gradient(135deg, #3B82F6, #2563EB); }
                .lp-stat-bg-green  { background: linear-gradient(135deg, #22C55E, #16A34A); }
                .lp-stat-bg-orange { background: linear-gradient(135deg, #FB923C, #F97316); }
                .lp-stat-bg-pink   { background: linear-gradient(135deg, #EC4899, #DB2777); }
                .lp-actions-list {
                    list-style: none;
                    margin: 8px 0 0 0;
                    padding: 0;
                    display: flex;
                    flex-direction: column;
                    gap: 8px;
                }
                .lp-action-item {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    padding: 8px 10px;
                    border-radius: 12px;
                    background: #F9FAFB;
                }
                .lp-action-text {
                    font-size: 13px;
                    font-weight: 500;
                    color: #111827;
                }
                .lp-action-hint {
                    font-size: 11px;
                    color: #6B7280;
                }
                .lp-action-btn {
                    font-size: 11px;
                    padding: 5px 10px;
                    border-radius: 999px;
                    border: none;
                    cursor: pointer;
                    background: #111827;
                    color: #ffffff;
                }
                .lp-footer-note {
                    margin-top: 12px;
                    font-size: 11px;
                    color: #9CA3AF;
                    text-align: right;
                }
                .lp-activity-list {
                    list-style: none;
                    margin: 0;
                    padding: 0;
                }
                .lp-activity-item {
                    padding: 7px 0;
                    border-bottom: 1px solid #E5E7EB;
                    font-size: 12px;
                    color: #374151;
                }
                .lp-activity-item:last-child {
                    border-bottom: none;
                }
                .lp-activity-time {
                    font-size: 11px;
                    color: #9CA3AF;
                    display: block;
                }
            </style>

            <div class="lp-header">
                <div class="lp-header-main">
                    <div class="lp-badge">LinkPilot · Beta</div>
                    <h1 class="lp-header-title">Automate your internal links — without breaking your site.</h1>
                    <p class="lp-header-subtitle">
                        Scan blog posts, discover relevant WooCommerce products, and insert smart internal links
                        in a few clicks. No messy settings, no manual link hunting.
                    </p>
                </div>
                <div class="lp-header-actions">
                    <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=linkpilot-dashboard&lp_action=scan_now' ), 'linkpilot_scan_now' ) ); ?>" class="lp-primary-btn">
                        <span>Run Bulk Scan</span>
                        <span>→</span>
                    </a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=linkpilot-logs' ) ); ?>" class="lp-secondary-link">
                        View link activity
                    </a>
                </div>
            </div>

            <div class="lp-grid">
                <div class="lp-card">
                    <div class="lp-card-header">
                        <div>
                            <h2 class="lp-card-title">LinkPilot Overview</h2>
                            <p class="lp-card-subtitle">A quick snapshot of your internal linking activity.</p>
                        </div>
                    </div>

                    <div class="lp-stats">
                        <div class="lp-stat-card lp-stat-bg-blue">
                            <div class="lp-stat-label">Posts scanned</div>
                            <div class="lp-stat-value"><?php echo esc_html( $total_posts ); ?></div>
                            <div class="lp-stat-meta">Published blog posts</div>
                        </div>
                        <div class="lp-stat-card lp-stat-bg-green">
                            <div class="lp-stat-label">Links inserted</div>
                            <div class="lp-stat-value"><?php echo esc_html( $stats['total_links'] ); ?></div>
                            <div class="lp-stat-meta">Active LinkPilot links</div>
                        </div>
                        <div class="lp-stat-card lp-stat-bg-orange">
                            <div class="lp-stat-label">Posts affected</div>
                            <div class="lp-stat-value"><?php echo esc_html( $stats['posts_affected'] ); ?></div>
                            <div class="lp-stat-meta">Posts with LinkPilot links</div>
                        </div>
                        <div class="lp-stat-card lp-stat-bg-pink">
                            <div class="lp-stat-label">Last run</div>
                            <div class="lp-stat-value" style="font-size:13px;"><?php echo esc_html( $last_run_label ); ?></div>
                            <div class="lp-stat-meta">Bulk engine status</div>
                        </div>
                    </div>

                    <ul class="lp-actions-list">
                        <li class="lp-action-item">
                            <div>
                                <div class="lp-action-text">Scan all blog posts</div>
                                <div class="lp-action-hint">Use OpenRouter to suggest contextual internal links.</div>
                            </div>
                            <a class="lp-action-btn" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=linkpilot-dashboard&lp_action=scan_now' ), 'linkpilot_scan_now' ) ); ?>">Start scan</a>
                        </li>
                        <li class="lp-action-item">
                            <div>
                                <div class="lp-action-text">Review recent links</div>
                                <div class="lp-action-hint">See where LinkPilot added links and to which targets.</div>
                            </div>
                            <a class="lp-action-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=linkpilot-logs' ) ); ?>">Open activity</a>
                        </li>
                        <li class="lp-action-item">
                            <div>
                                <div class="lp-action-text">Configure OpenRouter</div>
                                <div class="lp-action-hint">Add your API key and model in settings.</div>
                            </div>
                            <a class="lp-action-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=linkpilot-settings' ) ); ?>">Settings</a>
                        </li>
                    </ul>

                    <div class="lp-footer-note">
                        Coming soon: topic clusters, per-post previews, and undo queue.
                    </div>
                </div>

                <div class="lp-card">
                    <div class="lp-card-header">
                        <div>
                            <h2 class="lp-card-title">Recent activity</h2>
                            <p class="lp-card-subtitle">Latest links created by LinkPilot.</p>
                        </div>
                    </div>
                    <?php if ( ! empty( $recent_activity ) ) : ?>
                        <ul class="lp-activity-list">
                            <?php foreach ( $recent_activity as $row ) :
                                $post_title = get_the_title( intval( $row['post_id'] ) );
                                $post_edit  = get_edit_post_link( intval( $row['post_id'] ) );
                                ?>
                                <li class="lp-activity-item">
                                    <strong><?php echo esc_html( $post_title ? $post_title : '(Post ID ' . intval( $row['post_id'] ) . ')' ); ?></strong><br/>
                                    <span><?php echo esc_html( wp_trim_words( $row['anchor_text'], 10, '…' ) ); ?></span>
                                    <span class="lp-activity-time">
                                        <?php echo esc_html( mysql2date( 'M j, Y H:i', $row['created_at'] ) ); ?>
                                        <?php if ( $post_edit ) : ?>
                                            · <a href="<?php echo esc_url( $post_edit ); ?>">View post</a>
                                        <?php endif; ?>
                                    </span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else : ?>
                        <p style="font-size:13px; color:#6B7280;">No LinkPilot activity yet. Run a bulk scan to get started.</p>
                    <?php endif; ?>
                    <p style="font-size:12px; margin-top:10px; color:#6B7280;">
                        Tip: Start with a smaller batch of posts first, review the results, then run a full scan.
                    </p>
                </div>
            </div>
        </div>
        <?php
    }

    public function render_logs_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'You do not have sufficient permissions to access this page.', 'linkpilot' ) );
        }

        global $wpdb;

        $links = $wpdb->get_results(
            "SELECT * FROM {$this->links_table} ORDER BY created_at DESC LIMIT 100",
            ARRAY_A
        );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Link Activity', 'linkpilot' ); ?></h1>
            <p><?php esc_html_e( 'These are the most recent links inserted by LinkPilot.', 'linkpilot' ); ?></p>
            <table class="widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Date', 'linkpilot' ); ?></th>
                        <th><?php esc_html_e( 'Post', 'linkpilot' ); ?></th>
                        <th><?php esc_html_e( 'Anchor Text', 'linkpilot' ); ?></th>
                        <th><?php esc_html_e( 'Target URL', 'linkpilot' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'linkpilot' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( ! empty( $links ) ) : ?>
                        <?php foreach ( $links as $row ) :
                            $post_title = get_the_title( intval( $row['post_id'] ) );
                            $post_edit  = get_edit_post_link( intval( $row['post_id'] ) );
                            ?>
                            <tr>
                                <td><?php echo esc_html( mysql2date( 'M j, Y H:i', $row['created_at'] ) ); ?></td>
                                <td>
                                    <?php if ( $post_edit ) : ?>
                                        <a href="<?php echo esc_url( $post_edit ); ?>">
                                            <?php echo esc_html( $post_title ? $post_title : '(Post ID ' . intval( $row['post_id'] ) . ')' ); ?>
                                        </a>
                                    <?php else : ?>
                                        <?php echo esc_html( $post_title ? $post_title : '(Post ID ' . intval( $row['post_id'] ) . ')' ); ?>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html( wp_trim_words( $row['anchor_text'], 10, '…' ) ); ?></td>
                                <td style="word-break:break-all;"><?php echo esc_html( $row['target_url'] ); ?></td>
                                <td><?php echo esc_html( ucfirst( $row['status'] ) ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr><td colspan="5"><?php esc_html_e( 'No links logged yet.', 'linkpilot' ); ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function render_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'You do not have sufficient permissions to access this page.', 'linkpilot' ) );
        }

        // Handle form submit.
        if ( isset( $_POST['linkpilot_settings_nonce'] ) && wp_verify_nonce( $_POST['linkpilot_settings_nonce'], 'linkpilot_save_settings' ) ) {
            $api_key = isset( $_POST['linkpilot_openrouter_api_key'] ) ? sanitize_text_field( $_POST['linkpilot_openrouter_api_key'] ) : '';
            $model   = isset( $_POST['linkpilot_openrouter_model'] ) ? sanitize_text_field( $_POST['linkpilot_openrouter_model'] ) : '';

            update_option( 'linkpilot_openrouter_api_key', $api_key );
            update_option( 'linkpilot_openrouter_model', $model );

            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings saved.', 'linkpilot' ) . '</p></div>';
        }

        $saved_api_key = get_option( 'linkpilot_openrouter_api_key', '' );
        $saved_model   = get_option( 'linkpilot_openrouter_model', 'openai/gpt-4.1-mini' );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'LinkPilot Settings', 'linkpilot' ); ?></h1>
            <form method="post">
                <?php wp_nonce_field( 'linkpilot_save_settings', 'linkpilot_settings_nonce' ); ?>

                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row">
                            <label for="linkpilot_openrouter_api_key"><?php esc_html_e( 'OpenRouter API Key', 'linkpilot' ); ?></label>
                        </th>
                        <td>
                            <input type="password" id="linkpilot_openrouter_api_key" name="linkpilot_openrouter_api_key" value="<?php echo esc_attr( $saved_api_key ); ?>" class="regular-text" autocomplete="off" />
                            <p class="description">
                                <?php esc_html_e( 'Your secret OpenRouter API key. Stored in your WordPress database and used server-side only.', 'linkpilot' ); ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="linkpilot_openrouter_model"><?php esc_html_e( 'OpenRouter Model', 'linkpilot' ); ?></label>
                        </th>
                        <td>
                            <input type="text" id="linkpilot_openrouter_model" name="linkpilot_openrouter_model" value="<?php echo esc_attr( $saved_model ); ?>" class="regular-text" />
                            <p class="description">
                                <?php esc_html_e( 'Example: openai/gpt-4.1-mini or deepseek/deepseek-chat. Check your OpenRouter dashboard for available models.', 'linkpilot' ); ?>
                            </p>
                        </td>
                    </tr>
                </table>

                <?php submit_button( __( 'Save Settings', 'linkpilot' ) ); ?>
            </form>

            <h2><?php esc_html_e( 'How it works', 'linkpilot' ); ?></h2>
            <p><?php esc_html_e( 'When you run a bulk scan, LinkPilot sends the post content plus your product list to OpenRouter and asks it to respond with JSON describing which anchor texts to link to which URLs. Then it safely inserts those links and logs them in the activity table.', 'linkpilot' ); ?></p>
        </div>
        <?php
    }

    protected function run_bulk_scan() {
        $posts_scanned      = 0;
        $links_inserted     = 0;

        $api_key = get_option( 'linkpilot_openrouter_api_key', '' );
        $model   = get_option( 'linkpilot_openrouter_model', '' );

        // Collect products if WooCommerce is active.
        $products = array();
        if ( class_exists( 'WC_Product' ) && function_exists( 'wc_get_products' ) ) {
            $products = wc_get_products(
                array(
                    'status' => 'publish',
                    'limit'  => -1,
                )
            );
        }

        $product_map = array();
        foreach ( $products as $product ) {
            $product_map[] = array(
                'title' => html_entity_decode( $product->get_name(), ENT_QUOTES, 'UTF-8' ),
                'url'   => get_permalink( $product->get_id() ),
            );
        }

        $args  = array(
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
        );
        $posts = get_posts( $args );

        foreach ( $posts as $post_id ) {
            $posts_scanned++;
            $content          = get_post_field( 'post_content', $post_id );
            $original_content = $content;

            if ( empty( $content ) ) {
                continue;
            }

            $suggestions = array();

            if ( ! empty( $api_key ) && ! empty( $model ) && ! empty( $product_map ) ) {
                $suggestions = $this->get_openrouter_suggestions( $api_key, $model, $content, $product_map );
            }

            if ( empty( $suggestions ) ) {
                // Fallback to simple local engine if no AI suggestions.
                $suggestions = $this->get_simple_suggestions( $content, $product_map );
            }

            foreach ( $suggestions as $suggestion ) {
                $anchor_text = isset( $suggestion['anchor_text'] ) ? $suggestion['anchor_text'] : '';
                $target_url  = isset( $suggestion['target_url'] ) ? $suggestion['target_url'] : '';

                if ( empty( $anchor_text ) || empty( $target_url ) ) {
                    continue;
                }

                if ( strpos( $content, $target_url ) !== false ) {
                    continue;
                }

                $pattern     = '/(' . preg_quote( $anchor_text, '/' ) . ')(?![^<]*?>)/i';
                $replacement = '<a href="' . esc_url( $target_url ) . '" class="linkpilot-link" target="_blank" rel="noopener">$1</a>';

                $new_content = preg_replace( $pattern, $replacement, $content, 1 );
                if ( $new_content && $new_content !== $content ) {
                    $content = $new_content;
                    $links_inserted++;
                    $this->log_link( $post_id, $target_url, $anchor_text );
                }
            }

            if ( $content !== $original_content ) {
                wp_update_post(
                    array(
                        'ID'           => $post_id,
                        'post_content' => $content,
                    )
                );
            }
        }

        return array(
            'posts_scanned'  => $posts_scanned,
            'links_inserted' => $links_inserted,
        );
    }

    protected function get_simple_suggestions( $content, $product_map, $max_links_per_post = 3 ) {
        $suggestions        = array();
        $links_added_in_post = 0;

        foreach ( $product_map as $product ) {
            if ( $links_added_in_post >= $max_links_per_post ) {
                break;
            }

            $title = $product['title'];
            $url   = $product['url'];

            $words = preg_split( '/\s+/', trim( $title ) );
            if ( empty( $words ) ) {
                continue;
            }
            $keyword = implode( ' ', array_slice( $words, 0, min( 3, count( $words ) ) ) );

            if ( stripos( $content, $keyword ) === false ) {
                continue;
            }

            $suggestions[] = array(
                'anchor_text' => $keyword,
                'target_url'  => $url,
            );
            $links_added_in_post++;
        }

        return $suggestions;
    }

    protected function get_openrouter_suggestions( $api_key, $model, $content, $product_map ) {
        $endpoint = 'https://openrouter.ai/api/v1/chat/completions';

        $system_prompt = 'You are an SEO assistant that creates internal links between blog posts and WooCommerce products. '
            . 'You will receive the HTML content of a WordPress blog post and a list of candidate products (title + URL). '
            . 'Return a small JSON array of link suggestions. Each suggestion must have "anchor_text" (a short phrase from the post body) '
            . 'and "target_url" (one of the provided product URLs). Only suggest links where it feels natural and helpful. '
            . 'Reply with JSON only, no extra text.';

        $payload = array(
            'model'    => $model,
            'messages' => array(
                array(
                    'role'    => 'system',
                    'content' => $system_prompt,
                ),
                array(
                    'role'    => 'user',
                    'content' => wp_json_encode(
                        array(
                            'post_html'  => $content,
                            'products'   => $product_map,
                            'max_links'  => 3,
                        )
                    ),
                ),
            ),
        );

        $args = array(
            'headers' => array(
                'Authorization'   => 'Bearer ' . $api_key,
                'Content-Type'    => 'application/json',
                'Accept'          => 'application/json',
                'HTTP-Referer'    => home_url(),
                'X-Title'         => get_bloginfo( 'name' ) . ' - LinkPilot',
            ),
            'body'    => wp_json_encode( $payload ),
            'timeout' => 30,
        );

        $response = wp_remote_post( $endpoint, $args );

        if ( is_wp_error( $response ) ) {
            return array();
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code < 200 || $code >= 300 ) {
            return array();
        }

        $body = wp_remote_retrieve_body( $response );
        if ( empty( $body ) ) {
            return array();
        }

        $data = json_decode( $body, true );
        if ( ! isset( $data['choices'][0]['message']['content'] ) ) {
            return array();
        }

        $content_str = $data['choices'][0]['message']['content'];
        $json        = json_decode( $content_str, true );

        if ( json_last_error() !== JSON_ERROR_NONE || ! is_array( $json ) ) {
            return array();
        }

        $clean = array();
        foreach ( $json as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }
            if ( empty( $item['anchor_text'] ) || empty( $item['target_url'] ) ) {
                continue;
            }
            $clean[] = array(
                'anchor_text' => wp_strip_all_tags( $item['anchor_text'] ),
                'target_url'  => esc_url_raw( $item['target_url'] ),
            );
        }

        return $clean;
    }

    protected function log_link( $post_id, $target_url, $anchor_text ) {
        global $wpdb;

        $wpdb->insert(
            $this->links_table,
            array(
                'post_id'     => intval( $post_id ),
                'target_url'  => $target_url,
                'anchor_text' => $anchor_text,
                'created_at'  => current_time( 'mysql' ),
                'status'      => 'active',
            ),
            array(
                '%d',
                '%s',
                '%s',
                '%s',
                '%s',
            )
        );
    }
}

endif;
