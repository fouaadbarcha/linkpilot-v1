<?php
/*
Plugin Name: LinkPilot
Plugin URI: https://fouaad.dev
Description: AI-powered internal linking assistant for WordPress with an analytics dashboard.
Version: 2.0.0
Author: Fouaad Barcha
Author URI: https://fouaad.dev
Text Domain: linkpilot
IMPORTANT: To use this plugin, you will need to get an API key from Openrouter.ai. It is free and you can get the key in under 2 minutes. 
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'LINKPILOT_VERSION' ) ) {
    define( 'LINKPILOT_VERSION', '2.3.0' );
}
if ( ! defined( 'LINKPILOT_PATH' ) ) {
    define( 'LINKPILOT_PATH', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'LINKPILOT_URL' ) ) {
    define( 'LINKPILOT_URL', plugin_dir_url( __FILE__ ) );
}

// Load main plugin class.
require_once LINKPILOT_PATH . 'includes/class-linkpilot.php';

// Activation hook.
register_activation_hook( __FILE__, array( 'LinkPilot', 'activate' ) );

// Bootstrap plugin.
add_action( 'plugins_loaded', array( 'LinkPilot', 'instance' ) );
