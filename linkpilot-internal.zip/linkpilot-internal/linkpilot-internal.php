<?php
/*
Plugin Name: LinkPilot Internal (Dev Build)
Description: Internal AI-powered internal linking assistant using DeepSeek.
Version: 0.1.0
Author: Fouaad Barcha
Author URI: https://fouaad.dev
*/

// ====================== CONFIGURATION ======================
//
// IMPORTANT:
// Replace 'YOUR_DEEPSEEK_API_KEY_HERE' with your real DeepSeek API key.
// Example: define( 'LINKPILOT_DEEPSEEK_API_KEY', 'sk-xxxxxxxx' );

if ( ! defined( 'LINKPILOT_DEEPSEEK_API_KEY' ) ) {
    define( 'LINKPILOT_DEEPSEEK_API_KEY', 'YOUR_DEEPSEEK_API_KEY_HERE' );
}

// Default model (you can change this if needed)
if ( ! defined( 'LINKPILOT_DEEPSEEK_MODEL' ) ) {
    define( 'LINKPILOT_DEEPSEEK_MODEL', 'deepseek-chat' );
}

// ====================== ADMIN MENU ======================

add_action( 'admin_menu', 'linkpilot_internal_add_admin_menu' );

function linkpilot_internal_add_admin_menu() {
    add_management_page(
        'LinkPilot Internal',
        'LinkPilot Internal',
        'manage_options',
        'linkpilot-internal',
        'linkpilot_internal_render_admin_page'
    );
}

// ====================== ADMIN PAGE RENDER ======================

function linkpilot_internal_render_admin_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $result = null;
    $error  = null;

    if (
        isset( $_POST['linkpilot_internal_nonce'], $_POST['linkpilot_post_id'] ) &&
        wp_verify_nonce( $_POST['linkpilot_internal_nonce'], 'linkpilot_internal_analyze' )
    ) {
        $post_id = absint( $_POST['linkpilot_post_id'] );

        if ( $post_id > 0 ) {
            $analysis = linkpilot_internal_analyze_post( $post_id );

            if ( is_wp_error( $analysis ) ) {
                $error = $analysis->get_error_message();
            } else {
                $result = $analysis;
            }
        } else {
            $error = 'Invalid post selected.';
        }
    }

    // Fetch latest 50 posts + pages
    $posts = get_posts( array(
        'post_type'      => array( 'post', 'page' ),
        'numberposts'    => 50,
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC',
    ) );

    ?>
    <div class="wrap">
        <h1>LinkPilot Internal (Dev Build)</h1>

        <?php if ( LINKPILOT_DEEPSEEK_API_KEY === 'YOUR_DEEPSEEK_API_KEY_HERE' ) : ?>
            <div class="notice notice-error">
                <p><strong>DeepSeek API key not set.</strong> Edit <code>wp-content/plugins/linkpilot-internal/linkpilot-internal.php</code> and replace <code>YOUR_DEEPSEEK_API_KEY_HERE</code> with your real API key.</p>
            </div>
        <?php endif; ?>

        <p>
            Select a post or page, send its content to DeepSeek, and get
            structured internal link suggestions for this site.
        </p>

        <form method="post" style="margin:20px 0; padding:15px; background:#fff; border:1px solid #ddd; max-width:650px;">
            <?php wp_nonce_field( 'linkpilot_internal_analyze', 'linkpilot_internal_nonce' ); ?>

            <p><strong>Select a post or page to analyze:</strong></p>
            <p>
                <select name="linkpilot_post_id" style="min-width:100%; max-width:100%;">
                    <option value="">— Choose a post/page —</option>
                    <?php foreach ( $posts as $post ) : ?>
                        <option value="<?php echo esc_attr( $post->ID ); ?>">
                            <?php
                            echo esc_html( $post->post_type === 'page' ? '[Page] ' : '[Post] ' );
                            echo esc_html( $post->post_title );
                            ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </p>

            <p>
                <button type="submit" class="button button-primary">
                    Analyze with DeepSeek
                </button>
            </p>
        </form>

        <?php if ( $error ) : ?>
            <div class="notice notice-error">
                <p><strong>Error:</strong> <?php echo esc_html( $error ); ?></p>
            </div>
        <?php endif; ?>

        <?php if ( $result && ! empty( $result['links'] ) ) : ?>
            <h2>Suggested Internal Links</h2>
            <p>Copy these anchors and URLs into your content manually for now.</p>

            <table class="widefat striped" style="margin-top:15px;">
                <thead>
                    <tr>
                        <th style="width:25%;">Suggested Anchor Text</th>
                        <th style="width:45%;">Target URL</th>
                        <th style="width:30%;">Reason / Note</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $result['links'] as $link ) : ?>
                        <tr>
                            <td><?php echo esc_html( isset( $link['anchor'] ) ? $link['anchor'] : '' ); ?></td>
                            <td>
                                <?php if ( ! empty( $link['target_url'] ) ) : ?>
                                    <a href="<?php echo esc_url( $link['target_url'] ); ?>" target="_blank" rel="noopener">
                                        <?php echo esc_html( $link['target_url'] ); ?>
                                    </a>
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html( isset( $link['reason'] ) ? $link['reason'] : '' ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php elseif ( $result && empty( $result['links'] ) ) : ?>
            <div class="notice notice-info">
                <p>No internal linking suggestions were returned for this content.</p>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

// ====================== ANALYSIS LOGIC ======================

function linkpilot_internal_analyze_post( $post_id ) {
    if ( LINKPILOT_DEEPSEEK_API_KEY === 'YOUR_DEEPSEEK_API_KEY_HERE' ) {
        return new WP_Error( 'no_api_key', 'DeepSeek API key is not configured.' );
    }

    $post = get_post( $post_id );

    if ( ! $post ) {
        return new WP_Error( 'invalid_post', 'Post not found.' );
    }

    $site_url = get_bloginfo( 'url' );
    $title    = $post->post_title;
    $content  = wp_strip_all_tags( $post->post_content );

    $user_prompt = "You are an SEO assistant for the website {$site_url}.\n\n"
        . "Post title: {$title}\n\n"
        . "Post content:\n{$content}\n\n"
        . "Your task is to suggest useful INTERNAL links only (links that point to URLs on the same domain: {$site_url}).\n"
        . "Return your answer strictly as JSON with this structure:\n\n"
        . "{\n"
        . "  \"links\": [\n"
        . "    {\n"
        . "      \"anchor\": \"short anchor text to turn into a link\",\n"
        . "      \"target_url\": \"{$site_url}/example-target/\",\n"
        . "      \"reason\": \"why this internal link is relevant\"\n"
        . "    }\n"
        . "  ]\n"
        . "}\n\n"
        . "Do not include any extra text or explanations, ONLY valid JSON.";

    $body = array(
        'model'           => LINKPILOT_DEEPSEEK_MODEL,
        'response_format' => array( 'type' => 'json_object' ),
        'messages'        => array(
            array(
                'role'    => 'system',
                'content' => 'You are an SEO assistant specializing in internal linking for a website. You always respond in valid JSON when asked.',
            ),
            array(
                'role'    => 'user',
                'content' => $user_prompt,
            ),
        ),
        'max_tokens'      => 800,
    );

    $response = wp_remote_post(
        'https://api.deepseek.com/chat/completions',
        array(
            'headers' => array(
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . LINKPILOT_DEEPSEEK_API_KEY,
            ),
            'body'    => wp_json_encode( $body ),
            'timeout' => 40,
        )
    );

    if ( is_wp_error( $response ) ) {
        return new WP_Error( 'http_error', 'HTTP error when calling DeepSeek: ' . $response->get_error_message() );
    }

    $code = wp_remote_retrieve_response_code( $response );

    if ( $code < 200 || $code >= 300 ) {
        return new WP_Error(
            'bad_status',
            'DeepSeek API returned HTTP ' . $code . '. Body: ' . wp_remote_retrieve_body( $response )
        );
    }

    $data = json_decode( wp_remote_retrieve_body( $response ), true );

    if ( ! is_array( $data ) || empty( $data['choices'][0]['message']['content'] ) ) {
        return new WP_Error( 'invalid_response', 'Unexpected DeepSeek response format.' );
    }

    $content_json = $data['choices'][0]['message']['content'];

    $parsed = json_decode( $content_json, true );

    if ( ! is_array( $parsed ) ) {
        return new WP_Error( 'invalid_json', 'DeepSeek did not return valid JSON. Raw content: ' . $content_json );
    }

    if ( empty( $parsed['links'] ) || ! is_array( $parsed['links'] ) ) {
        $parsed['links'] = array();
    }

    return $parsed;
}
